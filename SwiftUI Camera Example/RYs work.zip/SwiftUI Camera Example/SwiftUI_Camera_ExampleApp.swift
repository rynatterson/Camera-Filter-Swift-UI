//
//  SwiftUI_Camera_ExampleApp.swift
//  SwiftUI Camera Example
//
//  Created by Ry Natterson on 3/16/23.
//

import SwiftUI

@main
struct SwiftUI_Camera_ExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
